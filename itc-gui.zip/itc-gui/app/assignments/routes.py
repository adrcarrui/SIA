from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from sqlalchemy.orm import joinedload
from sqlalchemy import or_, cast, String
from . import bp
from app.db import SessionLocal
from app.models import Assignment, Device, Course, User, Movements
from datetime import date, datetime, timedelta

def log_movement_assignment(db, *, user_id, assignment, device, course, action, before, after, success=True):
    """
    Helper para insertar un registro en movements para una Assignment.
    """
    m = Movements(
        user_id=user_id,
        entity_type="device",
        entity_id=device.id if device is not None else None,
        action=action,
        before_data=before,
        after_data=after,
        success=success,
        description=f"Assignment {action}: device {device.id} -> course {course.id}",
        user_agent=request.user_agent.string,
    )
    db.add(m)

@bp.route("/", methods=["GET"])
@login_required
def index():
    db = SessionLocal()

    q = (request.args.get("q") or "").strip()
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)

    query = (
        db.query(Assignment)
        .options(
            joinedload(Assignment.device),
            joinedload(Assignment.course),
            joinedload(Assignment.creator),
        )
        .order_by(Assignment.id.desc())
    )

    if q:
        term = f"%{q}%"
        query = query.filter(
            or_(
                Assignment.status.ilike(term),
                Assignment.notes.ilike(term),
                cast(Assignment.id, String).ilike(term),
                cast(Assignment.device_id, String).ilike(term),
                cast(Assignment.course_id, String).ilike(term),
                Device.name.ilike(term),
                Course.name.ilike(term),
                Assignment.creator.has(
                    or_(
                        User.username.ilike(term),
                        User.email.ilike(term),
                    )
                ),
            )
        )

    total = query.count()

    assigns = (
        query
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    has_prev = page > 1
    has_next = page * per_page < total

    return render_template(
        "assignments/index.html",
        assigns=assigns,
        q=q,
        page=page,
        per_page=per_page,
        has_prev=has_prev,
        has_next=has_next,
        total=total,
    )


@bp.route("/new", methods=["GET", "POST"])
@login_required
def new():
    db = SessionLocal()
    devices = db.query(Device).all()
    courses = db.query(Course).all()

    if request.method == "POST":
        device_id = request.form.get("device_id")
        course_id = request.form.get("course_id")
        notes = request.form.get("notes") or None

        a = Assignment(
            device_id=device_id,
            course_id=course_id,
            status="active",
            created_by=current_user.id,
            notes=notes,
        )

        db.add(a)
        db.commit()
        flash("Asignación creada correctamente.", "success")
        return redirect(url_for("assignments.index"))

    # GET → mostrar formulario
    return render_template(
        "assignments/form.html",
        title="Nueva asignación",
        form_action=url_for("assignments.new"),
        assignment=None,
        devices=devices,
        courses=courses,
    )


@bp.route("/<int:id>/edit", methods=["GET", "POST"])
@login_required
def edit(id):
    db = SessionLocal()
    a = db.query(Assignment).get(id)
    if not a:
        flash("Asignación no encontrada.", "danger")
        return redirect(url_for("assignments.index"))

    devices = db.query(Device).all()
    courses = db.query(Course).all()

    if request.method == "POST":
        a.device_id = request.form.get("device_id")
        a.course_id = request.form.get("course_id")
        a.notes = request.form.get("notes") or None
        a.status = request.form.get("status")

        db.commit()
        flash("Asignación actualizada.", "success")
        return redirect(url_for("assignments.index"))

    # GET → mostrar formulario con datos
    return render_template(
        "assignments/form.html",
        title=f"Editar asignación #{a.id}",
        form_action=url_for("assignments.edit", id=a.id),
        assignment=a,
        devices=devices,
        courses=courses,
    )


@bp.route("/<int:id>/delete", methods=["POST"])
@login_required
def delete(id):
    db = SessionLocal()
    a = db.query(Assignment).get(id)
    if not a:
        flash("Asignación no encontrada.", "danger")
        return redirect(url_for("assignments.index"))

    db.delete(a)
    db.commit()
    flash("Asignación eliminada.", "success")
    return redirect(url_for("assignments.index"))


@bp.route("/bulk-new", methods=["GET", "POST"])
@login_required
def new_bulk():
    db = SessionLocal()

    # -----------------------
    # GET → mostrar formulario
    # -----------------------
    if request.method == "GET":
        course_id = request.args.get("course_id", type=int)
        if not course_id:
            abort(400, "course_id is required")

        course = db.query(Course).get(course_id)
        if not course:
            abort(404, "Course not found")

        return render_template("assignments/new_bulk.html", course=course)

    # -----------------------
    # POST → procesar NFC
    # -----------------------
    course_id = request.form.get("course_id", type=int)
    if not course_id:
        abort(400, "course_id is required")

    course = db.query(Course).get(course_id)
    if not course:
        abort(404, "Course not found")

    course_id_value = course.id
    uids = request.form.getlist("uids[]")

    if not uids:
        flash("No cards received to assign.", "warning")
        db.close()
        return redirect(url_for("courses.detail", course_id=course_id_value))

    try:
        # Buscar devices por UID
        devices = db.query(Device).filter(Device.uid.in_(uids)).all()
        devices_by_uid = {d.uid: d for d in devices}

        created_count = 0
        skipped_not_available = []
        skipped_already_assigned = []
        skipped_not_found = []

        for uid in uids:
            device = devices_by_uid.get(uid)

            if not device:
                skipped_not_found.append(uid)
                continue

            # Device debe estar available
            if device.status != "available":
                skipped_not_available.append(device)
                continue

            # NO duplicar asignaciones activas
            asig_existente = (
                db.query(Assignment)
                .filter(
                    Assignment.course_id == course_id_value,
                    Assignment.device_id == device.id,
                    Assignment.status == "active"
                )
                .first()
            )

            if asig_existente:
                skipped_already_assigned.append(device)
                continue

            # Crear Assignment
            assignment = Assignment(
                course_id=course_id_value,
                device_id=device.id,
                assigned_at=datetime.utcnow(),
                created_by=current_user.id,
                status="active",
            )
            db.add(assignment)
            db.flush()  # NECESARIO para assignment.id

            before = {"device_status": device.status}

            # Device pasa a assigned
            device.status = "assigned"

            after = {
                "device_status": device.status,
                "assignment_status": assignment.status,
                "assigned_at": assignment.assigned_at.isoformat(),
            }

            # AUDITORÍA
            log_movement_assignment(
                db,
                user_id=current_user.id,
                assignment=assignment,
                device=device,
                course=course,
                action="assign",
                before=before,
                after=after,
                success=True,
            )

            created_count += 1

        db.commit()

        # Mensajes
        if created_count:
            flash(f"{created_count} devices assigned to course.", "success")

        if skipped_not_available:
            flash(
                "Devices not available: " +
                ", ".join(d.name or f"Device #{d.id}" for d in skipped_not_available),
                "warning"
            )

        if skipped_already_assigned:
            flash(
                "Already linked to course: " +
                ", ".join(d.name or f"Device #{d.id}" for d in skipped_already_assigned),
                "info"
            )

        if skipped_not_found:
            flash(
                "Unknown cards: " + ", ".join(skipped_not_found),
                "danger"
            )

    except Exception as e:
        db.rollback()
        print("Error in new_bulk:", e)
        flash("Error assigning devices.", "danger")
    finally:
        db.close()

    return redirect(url_for("courses.detail", course_id=course_id_value))


@bp.route("/bulk-return", methods=["GET", "POST"])
@login_required
def bulk_return():
    db = SessionLocal()

    # GET → mostrar formulario de Return
    if request.method == "GET":
        course_id = request.args.get("course_id", type=int)
        if not course_id:
            abort(400, "course_id is required")

        course = db.query(Course).get(course_id)
        if not course:
            abort(404, "Course not found")

        return render_template("assignments/bulk_return.html", course=course)

    # POST → procesar devoluciones
    course_id = request.form.get("course_id", type=int)
    if not course_id:
        abort(400, "course_id is required")

    course = db.query(Course).get(course_id)
    if not course:
        abort(404, "Course not found")

    course_id_value = course.id
    uids = request.form.getlist("uids[]")

    if not uids:
        flash("No cards received to return.", "warning")
        db.close()
        return redirect(url_for("courses.detail", course_id=course_id_value))

    try:
        devices = (
            db.query(Device)
            .filter(Device.uid.in_(uids))
            .all()
        )
        devices_by_uid = {d.uid: d for d in devices}

        returned_count = 0
        skipped_not_found = []
        skipped_no_assignment = []

        for uid in uids:
            device = devices_by_uid.get(uid)

            if not device:
                skipped_not_found.append(uid)
                continue

            # Buscar la última asignación de ese device en este curso
            q = db.query(Assignment).filter(
                Assignment.device_id == device.id,
                Assignment.course_id == course_id_value,
            )

            if hasattr(Assignment, "status"):
                q = q.order_by(
                    (Assignment.status == "assigned").desc(),
                    Assignment.assigned_at.desc(),
                )
            else:
                q = q.order_by(Assignment.assigned_at.desc())

            assignment = q.first()

            if not assignment:
                skipped_no_assignment.append(device)
                # aun así devolvemos el device a available
                old_device_status = getattr(device, "status", None)
                if hasattr(Device, "status"):
                    device.status = "available"

                log_movement_assignment(
                    db,
                    user_id=current_user.id,
                    assignment=assignment,
                    device=device,
                    course=course,
                    action="assign",
                    before={"device_status": old_device_status},
                    after={"device_status": getattr(device, "status", None)},
                    success=True,
                )
                returned_count += 1
                continue

            # Guardar estado anterior
            before_data = {
                "assignment_status": getattr(assignment, "status", None),
                "returned_at": getattr(assignment, "returned_at", None).isoformat()
                    if getattr(assignment, "returned_at", None)
                    else None,
                "device_status": getattr(device, "status", None),
            }

            # Marcar devolución
            if hasattr(Assignment, "status"):
                assignment.status = "returned"
            if hasattr(Assignment, "returned_at"):
                assignment.returned_at = datetime.utcnow()

            old_device_status = getattr(device, "status", None)
            if hasattr(Device, "status"):
                device.status = "available"

            after_data = {
                "assignment_status": getattr(assignment, "status", None),
                "returned_at": getattr(assignment, "returned_at", None).isoformat()
                    if getattr(assignment, "returned_at", None)
                    else None,
                "device_status": getattr(device, "status", None),
            }

            # AUDITORÍA: movimiento de devolución
            log_movement_assignment(
                db,
                user_id=current_user.id,
                assignment=assignment,
                device=device,
                course=course,
                action="returned",
                before=before_data,
                after=after_data,
                success=True,
            )

            returned_count += 1

        db.commit()

        if returned_count:
            flash(f"{returned_count} devices returned to stock.", "success")

        if skipped_no_assignment:
            names = ", ".join(
                f"{d.name or 'Device #' + str(d.id)}" for d in skipped_no_assignment
            )
            flash(
                f"Some devices had no active assignment; only device status was changed: {names}",
                "warning",
            )

        if skipped_not_found:
            flash(
                f"Some UIDs did not match any device and were skipped: {', '.join(skipped_not_found)}",
                "warning",
            )

    except Exception as e:
        db.rollback()
        print("Error in bulk_return:", e)
        flash("Error returning devices.", "danger")
    finally:
        db.close()

    return redirect(url_for("courses.detail", course_id=course_id_value))
